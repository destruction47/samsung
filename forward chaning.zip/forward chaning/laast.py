from itertools import combinations
import sys
d={}
l=[]
path=[]
count=0
final=[]
with open('rules.txt') as f:
    R = f.read().split()
    for i in R:
        rule_dict=i.split(',')
        d[rule_dict[0]]=rule_dict[1]
print(d)
with open('goal.txt') as f:
    G = f.read() 
print(G)
with open('facts.txt') as f:
    F = f.read().replace(' ','')
    for i in F:
        if(i!=' '):
            l.append(i)
            path.append(i)
            final.append('pre')
            final.append(i)          
print(F)
def check_rule(x):
    combi=[''.join(l) for i in range(len(x)) for l in combinations(x, i+1)]
    #print(combi)
    for i in combi:
        if i in d:
            if d[i] in combi:
                continue
            return d[i],i
    else:
        return -1      
while G not in path:
    count+1
    a,b=check_rule(path)
    path.append(a)
    final.append(b)
    final.append(a)
    if count>(len(R)**len(R)):
        print("no valid path")
        sys.exit
    print(path)
    print(final)
def print_path(final):
    print("path followed")
    for i in range(0,len(final),2):
        print(final[i] +"->",end='')
        print(final[i+1])
print_path(final)